<!doctype>
<html>
    <head>
        <meta charset="utf-8">
        <title>Order Confirmed</title>
    </head>
    <body>
    <h3>Welcome to Atrium Shop</h3>
    <p>Hello {{$name}},</p><br>
    <p>Your order was confirmed with code: <strong>{{$order_code}}</strong>, and with
        the payment type of {{$payment_type}}.</p>
    </body>
</html>