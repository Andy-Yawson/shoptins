<ul class="menu-category">
	<li><a href="{{ route('user.account.orders') }}">My Orders</a></li>
	<li><a href="{{ route('user.change.password') }}">Change Password</a></li>
	<li><a href="{{ route('user.change.address') }}">Change Address</a></li>
</ul>