<ul class="menu-category">
	<li><a href="<?php echo e(route('user.account.orders')); ?>">My Orders</a></li>
	<li><a href="<?php echo e(route('user.change.password')); ?>">Change Password</a></li>
	<li><a href="<?php echo e(route('user.change.address')); ?>">Change Address</a></li>
</ul><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/user/account/menu.blade.php ENDPATH**/ ?>