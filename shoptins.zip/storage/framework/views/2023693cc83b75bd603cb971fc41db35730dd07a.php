<?php $__env->startSection('content'); ?>

	<!-- ========================= SECTION PAGETOP ========================= -->
	<section class="section-pagetop bg-secondary">
		<div class="container clearfix">
			<h2 class="title-page">My Account</h2>
		</div> <!-- container //  -->
	</section>
	<!-- ========================= SECTION INTRO END// ========================= -->

	<!--================login Area =================-->
	<section class="emty_cart_area p_100">
		<div class="container">
			<div class="row mt-5 mb-5">
				<div class="col-md-3">
					<aside class="mb-2">
						<div class="card">
							<header class="card-header white category-header">
								<i class="icon-menu"></i>
								Shoptins Account
							</header>
							<?php echo $__env->make('user.account.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div> <!-- card.// -->
					</aside>
				</div>
				<div class="col-md-9">
					<div class="row">
						<div class="col-md-12">
							<div class="bgc-white bd bdrs-3 p-20 mB-20">
								<h4 class="c-grey-900 mB-20">Order Details For International</h4>
								<table class="table table-striped" cellspacing="0"
								       width="100%">
									<thead>
									<tr>
										<th>Product Link</th>
										<th>Origin</th>
										<th>Quantity</th>
										<th>Weight</th>
										<th>SubTotal</th>
									</tr>
									</thead>
									<tbody>
									<?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($detail->link); ?></td>
											<td><?php echo e($detail->origin); ?></td>
											<td><?php echo e($detail->quantity); ?></td>
											<td><?php echo e($detail->weight); ?></td>
											<td><?php echo e($detail->price * $detail->quantity); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
									<tfoot>
									<tr>
										<td colspan="4">Total With Admin Fee:</td>
										<td>
											<strong>
                                                <?php $total = 0;$check = false; ?>
												<?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $total = ($total + $detail->price) * $detail->quantity  ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($detail->shopper_assist == 1): ?>
                                                        <?php $check = true; ?>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if($check): ?>
													= &#8373;<?php echo e($total + 50); ?>

												<?php else: ?>
													= &#8373;<?php echo e($total); ?>

												<?php endif; ?>
											</strong>
										</td>
									</tr>
									<tr>
										<td colspan="4"></td>
										<td>
											<?php if($order->status == 2): ?>
												<a href="<?php echo e(route('user.int.replace.order',$order->order_code)); ?>"><button class="btn btn-success">Re-Place Order</button></a>
											<?php else: ?>
												<a href="<?php echo e(route('user.int.decline.order',$order->order_code)); ?>"><button class="btn btn-danger">Cancel Order</button></a>
											<?php endif; ?>
										</td>
									</tr>
									</tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterint', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/user/account/int-detail.blade.php ENDPATH**/ ?>