<?php $__env->startSection('content'); ?>


<!-- ========================= SECTION MAIN ========================= -->
<section class="section-main bg padding-top-sm">
    <div class="container">

        <div class="row row-sm">
            <aside class="col-md-3 mb-2">
                <div class="card">
                    <header class="card-header white category-header">
	                    <a href="#" data-toggle="collapse" data-target="#collapseCategory" aria-expanded="true" class="collapsed">
		                    <i class="icon-action fa fa-chevron-down"></i>
		                    <h6 class="title">Categories</h6>
	                    </a>
                    </header>
	                <div class="filter-content collapse show" id="collapseCategory">
                        <ul class="menu-category">
                        <?php $categories = \App\Category::orderBy('created_at','asc')->limit(6)->get(); ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('user.shop.category',$category->category_slug)); ?>">
                                    <?php echo e($category->category_name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('user.shop')); ?>">Show All Categories</a></li>
                    </ul>
	                </div>
                </div>
                <div class="card">
                    <header class="card-header white category-header">
	                    <a href="#" data-toggle="collapse" data-target="#collapseManufacturer" aria-expanded="true" class="collapsed">
		                    <i class="icon-action fa fa-chevron-down"></i>
	                        <h6 class="title">Manufacture</h6>
	                    </a>
                    </header>
	                <div class="filter-content collapse" id="collapseManufacturer">
		                <ul class="menu-category">
                            <?php $manufacturer = \App\Manufacture::orderBy('created_at','asc')->limit(6)->get(); ?>
			                <?php $__currentLoopData = $manufacturer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                <li>
					                <a href="<?php echo e(route('user.shop.manufacture',$manufacture->manufacture_slug)); ?>">
						                <?php echo e($manufacture->manufacture_name); ?>

					                </a>
				                </li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                <li><a href="<?php echo e(route('user.shop')); ?>">Show All Manufacturers</a></li>
		                </ul>
	                </div>
                </div>
            </aside>
            <div class="col-md-9">
                <div id="carousel2_indicator" class="carousel slide carousel-fade" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php if($loop->iteration == 1): ?> active <?php else: ?> '' <?php endif; ?>">
                                <img class="d-block w-100" src="<?php echo e(asset('images/slider_images/'.$slide->slider_image)); ?>"
                                     alt="slide image" height="390px">
                                
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carousel2_indicator" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carousel2_indicator" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div> <!-- col.// -->

        </div>
    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION MAIN END// ========================= -->

<!--============== Item Side ===================-->
<section class="section-content padding-y bg">
	<div class="container">
		<div id="code_itemside_round">
			<div class="row">
				<div class="col-md-6">
					<article class="list-group-item">
						<header class="filter-header">
							<a href="#" data-toggle="collapse" data-target="#collapse1" aria-expanded="true" class="collapsed">
								<i class="icon-action fa fa-chevron-down"></i>
								<h6 class="title">Benefits </h6>
							</a>
						</header>
						<div class="filter-content collapse" id="collapse1" style="">
							<ol>
								<li>We buy you the best products on the market at super prices</li>
								<li>Free  normal delivery within 7 hours</li>
								<li>GHC 10 -15 for express delivery within 2 hrs</li>
							</ol>
						</div> <!-- collapse -filter-content  .// -->
					</article>
				</div><!-- col // -->
				<div class="col-md-6">
					<article class="list-group-item">
						<header class="filter-header">
							<a href="#" data-toggle="collapse" data-target="#importantPoints" aria-expanded="true" class="collapsed">
								<i class="icon-action fa fa-chevron-down"></i>
								<h6 class="title">Important points</h6>
							</a>
						</header>
						<div class="filter-content collapse" id="importantPoints" style="">
							<ol>
								<li>You may be required to pay for the items on your shopping list before purchase</li>
								<li> Full payment will be required before package handover</li>
								<li>Cancelling order after delivery process has commenced comes at a cost</li>
								<li> Refunds to customers will be paid minus merchant transfer fees</li>
								<li>Shoptins requires that our users provide further specifications for selected products that come in varieties. This can be done in the comment box</li>
								<li>The Shoptins service cannot be used to purchase any illegal items</li>
							</ol>
						</div> <!-- collapse -filter-content  .// -->
					</article>
				</div><!-- col // -->

			</div> <!-- row.// -->
		</div> <!-- code-wrap.// -->
	</div>
</section>
<!--============== Item Side End===================-->


<!-- ========================= SECTION LATEST CONTENT ========================= -->
<section class="section-content padding-y bg">
    <div class="container">

        <div class="card mb-3">
            <div class="card-body">

                <header class="section-heading">
                    <h3 class="title-section">Our Products</h3>
                </header>

                <div class="row">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 mb-3">
                            <div class="card">
                                <figure class="itemside">
                                    <div class="aside">
                                        <div class="img-wrap img-sm border-right">
                                            <img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>">
                                        </div>
                                    </div>
                                    <figcaption class="p-3">
                                        <h6 class="title">
                                            <a href="<?php echo e(route('user.shop.product.detail',$item->slug)); ?>">
                                                <?php echo e($item->product_name); ?>

                                            </a>
                                        </h6>
                                        <div class="price-wrap">
                                            <?php if($item->product_del > 0): ?>
                                                <span class="price-new">&#8373;<?php echo e(round((1 - ($item->product_del/100)) * $item->product_price)); ?></span>
                                                <del class="price-old">&#8373;<?php echo e($item->product_price); ?></del>
                                            <?php else: ?>
                                                <span class="price-new">&#8373;<?php echo e($item->product_price); ?></span>
                                            <?php endif; ?>
                                        </div>
	                                    <a href="<?php echo e(route('user.shop.product.detail',$item->slug)); ?>" class="btn btn-primary">
		                                    <i class="fa fa-cart-plus"></i>
		                                    add to cart
	                                    </a>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div> <!-- card-body .// -->
        </div> <!-- card.// -->


    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION LATEST CONTENT END// ========================= -->


<!-- ========================= SECTION FEATURED CONTENT ========================= -->
<section class="section-content padding-y bg">
    <div class="container">
        <div class="card mb-3">
            <div class="card-body">

                <header class="section-heading">
                    <h3 class="title-section">Our Featured Products</h3>
                </header>
                <div class="row">
                    <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 mb-3">
                            <div class="card">
                                <figure class="itemside">
                                    <div class="aside">
                                        <div class="img-wrap img-sm border-right">
                                            <img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>">
                                        </div>
                                    </div>
                                    <figcaption class="p-3">
                                        <h6 class="title">
                                            <a href="<?php echo e(route('user.shop.product.detail',$item->slug)); ?>">
                                                <?php echo e($item->product_name); ?>

                                            </a>
                                        </h6>
                                        <div class="price-wrap">
                                            <?php if($item->product_del > 0): ?>
                                                <span class="price-new">&#8373;<?php echo e(round((1 - ($item->product_del/100)) * $item->product_price)); ?></span>
                                                <del class="price-old">&#8373;<?php echo e($item->product_price); ?></del>
                                            <?php else: ?>
                                                <span class="price-new">&#8373;<?php echo e($item->product_price); ?></span>
                                            <?php endif; ?>
                                        </div>
	                                    <a href="<?php echo e(route('user.shop.product.detail',$item->slug)); ?>" class="btn btn-primary">
		                                    <i class="fa fa-cart-plus"></i>
		                                    add to cart
	                                    </a>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div> <!-- card-body .// -->
        </div> <!-- card.// -->
    </div> <!-- container .//  -->
</section>
<!-- ========================= SECTION FEATURED CONTENT END// ========================= -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/welcome.blade.php ENDPATH**/ ?>