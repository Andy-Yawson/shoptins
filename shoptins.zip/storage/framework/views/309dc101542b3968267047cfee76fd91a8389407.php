<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-4">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">Customer Details</h4>
                        <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Full Name</th>
                                    <th>Phone Number</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($order_detail[0]->name); ?></td>
                                    <td>
                                        <?php echo e($order_detail[0]->phone); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">Shipping Details | Other Specifications</h4>
                        <?php if($order_detail[0]->address == "none"): ?>
                            <p>No shipping details provided</p>
                        <?php else: ?>
                            <?php echo e($order_detail[0]->address); ?>

                        <?php endif; ?>
                        <hr>
                        <?php if($order_detail[0]->other == "none"): ?>
                            <p>No spec details provided</p>
                        <?php else: ?>
                            <?php echo e($order_detail[0]->other); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">Order Details</h4>
                        <table class="table table-striped" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Code</th>
                                <th>Link</th>
                                <th>Qty</th>
                                <th>KG</th>
                                <th>Origin</th>
                                <th>Shopper Assist</th>
                                <th>Self Shopper</th>
                                <th>Price</th>
                                <th>SubTotal</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->order_code); ?></td>
                                        <td><?php echo e($detail->link); ?></td>
                                        <td><?php echo e($detail->quantity); ?></td>
                                        <td><?php echo e($detail->weight); ?></td>
                                        <td><?php echo e($detail->origin); ?></td>
                                        <td>
                                            <?php if($detail->shopper_assist == 1): ?>
                                                <p>yes</p>
                                            <?php else: ?>
                                                <p>No</p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($detail->self_shopper == 1): ?>
                                                <p>yes</p>
                                            <?php else: ?>
                                                <p>No</p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($detail->price); ?>

                                        </td>
                                        <td>
                                            <?php echo e($detail->price * $detail->quantity); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="8">Total With Admin Fee:</td>
                                <td>
                                    <strong>
                                        <?php $total = 0;$check = false; ?>
                                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $total = ($total + $detail->price) * $detail->quantity  ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($detail->shopper_assist == 1): ?>
                                                <?php $check = true; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($check): ?>
                                            = &#8373;<?php echo e($total + 50); ?>

                                        <?php else: ?>
                                            = &#8373;<?php echo e($total); ?>

                                        <?php endif; ?>
                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="9">
                                    <a href="<?php echo e(route('admin.order.confirm.int',$order_detail[0]->order_code)); ?>"><button class="btn btn-primary">Confirm Order</button></a>
                                    <a href="<?php echo e(route('admin.order.decline.int',$order_detail[0]->order_code)); ?>"><button class="btn btn-danger">Decline Order</button></a>
                                </td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/components/admin/view_order_int.blade.php ENDPATH**/ ?>