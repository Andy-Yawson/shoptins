<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">All Sliders</h4>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Desc</th>
                                <th>Product Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Desc</th>
                                <th>Product Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->slider_name); ?></td>
                                    <td><?php echo e(\Illuminate\Support\Str::words($item->slider_description,4,'...')); ?></td>
                                    <td align="center"><img src="<?php echo e(asset('images/slider_images/'.$item->slider_image)); ?>" height="100px" width="250px"></td>
                                    <td>
                                        <?php if($item->publication_status == 0): ?>
                                            <button class="btn btn-danger">Inactive</button>
                                        <?php else: ?>
                                            <button class="btn btn-success">Active</button>
                                        <?php endif; ?>
                                    </td>
                                    <td align="center">
                                        <?php if($item->publication_status == 0): ?>
                                            <a href="<?php echo e(route('admin.active.slider',$item->slider_id)); ?>"><i class="fa fa-thumbs-up fa-2x" style="color: green"></i></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('admin.unactive.slider',$item->slider_id)); ?>"><i class="fa fa-thumbs-o-down fa-2x" style="color: red"></i></a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('admin.delete.slider',$item->slider_id)); ?>"><i class="fa fa-trash-o fa-2x"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>