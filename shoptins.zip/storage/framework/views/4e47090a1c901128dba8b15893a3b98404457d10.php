

<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">All Products</h4>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Image</th>
                                <th>Product Price</th>
                                <th>Category</th>
                                <th>Manufacture</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Image</th>
                                <th>Product Price</th>
                                <th>Category</th>
                                <th>Manufacture</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->product_name); ?></td>
                                    <td align="center"><img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>" height="90px" width="90px"></td>
                                    <td>&#8373;<?php echo e($item->product_price); ?></td>
                                    <td><?php echo e($item->category_name); ?></td>
                                    <td><?php echo e($item->manufacture_name); ?></td>
                                    <td>
                                        <?php if($item->publication_status == 0): ?>
                                            <button class="btn btn-danger">Inactive</button>
                                        <?php else: ?>
                                            <button class="btn btn-success">Active</button>
                                        <?php endif; ?>
                                        <?php if($item->stock == 0): ?>
                                            <button class="btn btn-danger">Out Of Stock</button>
                                        <?php else: ?>
                                            <button class="btn btn-success">In Stock</button>
                                        <?php endif; ?>
                                    </td>
                                    <td align="center">
                                        <?php if($item->publication_status == 0): ?>
                                            <a title="make product active" href="<?php echo e(route('admin.active.product',$item->product_id)); ?>"><i class="fa fa-thumbs-up fa-2x" style="color: green"></i></a>
                                        <?php else: ?>
                                            <a title="make product inactive" href="<?php echo e(route('admin.unactive.product',$item->product_id)); ?>"><i class="fa fa-thumbs-o-down fa-2x" style="color: red"></i></a>
                                        <?php endif; ?>
                                        <?php if($item->stock == 0): ?>
                                            <a title="In stock" href="<?php echo e(route('admin.active.stock',$item->product_id)); ?>"><i class="fa fa-unlock fa-2x" style="color: green"></i></a>
                                        <?php else: ?>
                                            <a title="Out of stock" href="<?php echo e(route('admin.unactive.stock',$item->product_id)); ?>"><i class="fa fa-lock fa-2x" style="color: red"></i></a>
                                        <?php endif; ?>
                                        <a title="Delete Product" href="<?php echo e(route('admin.delete.product',$item->product_id)); ?>"><i class="fa fa-trash-o fa-2x"></i></a>
                                        <a title="Edit Product" href="<?php echo e(route('admin.edit.product',$item->product_id)); ?>"><i class="fa fa-edit fa-2x"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>