<?php $__env->startSection('content'); ?>

	<!-- ========================= SECTION PAGETOP ========================= -->
	<section class="section-pagetop bg-secondary">
		<div class="container clearfix">
			<h2 class="title-page">My Account</h2>
		</div> <!-- container //  -->
	</section>
	<!-- ========================= SECTION INTRO END// ========================= -->

	<!--================login Area =================-->
	<section class="emty_cart_area p_100">
		<div class="container">
			<div class="row mt-5 mb-5">
				<div class="col-md-3">
					<aside class="mb-2">
						<div class="card">
							<header class="card-header white category-header">
								<i class="icon-menu"></i>
								Shoptins Account
							</header>
							<?php echo $__env->make('user.account.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div> <!-- card.// -->
					</aside>
				</div>
				<div class="col-md-9">
					<div class="row">
						<div class="col-md-12">
							<div class="bgc-white bd bdrs-3 p-20 mB-20">
								<h4 class="c-grey-900 mB-20">Order Details</h4>
								<table class="table table-striped" cellspacing="0"
								       width="100%">
									<thead>
									<tr>
										<th>Product Name</th>
										<th>Product Price</th>
										<th>Product Sales Quantity</th>
										<th>Product SubTotal</th>
									</tr>
									</thead>
									<tbody>
									<?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($detail->product_name); ?></td>
											<td>&#8373;<?php echo e($detail->product_price); ?></td>
											<td><?php echo e($detail->product_sales_quantity); ?></td>
											<td>&#8373;<?php echo e(intval($detail->product_price) * intval($detail->product_sales_quantity)); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
									<tfoot>
									<tr>
										<td colspan="3">Total With VAT:</td>
										<td><strong>= &#8373;<?php echo e($order_detail[0]->order_total); ?></strong></td>
									</tr>
									<tr>
										<td colspan="3"></td>
										<td>
											<?php if($detail->order_status == 3): ?>
												<a href="<?php echo e(route('user.replace.order',$order_detail[0]->order_id)); ?>"><button class="btn btn-success">Replace Order</button></a>
											<?php else: ?>
												<a href="<?php echo e(route('user.decline.order',$order_detail[0]->order_id)); ?>"><button class="btn btn-danger">Cancel Order</button></a>
											<?php endif; ?>
										</td>
									</tr>
									</tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/user/account/detail.blade.php ENDPATH**/ ?>