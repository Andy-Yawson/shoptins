<?php $__env->startSection('styles'); ?>
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('home/css/slider-button.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<!-- ========================= SECTION PAGETOP ========================= -->
	<section class="section-pagetop bg-secondary">
		<div class="container clearfix">
			<h2 class="title-page">Payment Method</h2>
		</div> <!-- container //  -->
	</section>
	<!-- ========================= SECTION INTRO END// ========================= -->

	<!--================Track Area =================-->
	<section class="track_area p_100 mt-5">
		<div class="container">
			
			<div class="row">
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<h5 class="card-title">Address Details</h5>
						</div>
						<div class="card-body">
                            <?php
                            $data = \App\Shipping::where('user_id', auth()->user()->id)->first();
                            ?>
							<h6><?php echo e($data->shipping_name); ?></h6>
							<p><?php echo e($data->shipping_address); ?></p>
							<p><?php echo e($data->shipping_city); ?></p>
							<p><?php echo e($data->shipping_phone); ?></p>
                            <?php
                            ?>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card">
						<div class="card-header">
							<h5 class="card-title">Delivery Details</h5>
						</div>
						<div class="card-body">
							<h6>Home and Office Delivery</h6>
							<p>Our agent will call you to meet terms of delivery</p>
							<p>Your Payment Charge - <b><span style="color: orange">GH&#8373;<?php echo e(Cart::total()); ?></span></b></p>
							
						</div>
					</div>
				</div>
			</div>
			<form method="post" action="<?php echo e(route('user.shop.order.place')); ?>">
				<?php echo e(csrf_field()); ?>

				<div class="row" style="margin-top: 10px">
					<div class="col-md-12 mt-5">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title">
									Payment Method <b>(CHOOSE JUST ONE)</b><br>
									<small>Please be sure to choose the mode of
										payment by switching the button.</small>
								</h5>
							</div>
							<div class="card-body">
								<div class="row">
									<div class="col-lg-4">
										<div class="card">
											<div class="card-header">
												<h4 class="card-title">MTN Mobile Money</h4>
											</div>
											<div class="card-body">
												<ol>
													<li>Dial *170#</li>
													<li>Select Pay Bills</li>
													<li>Choose General Payment</li>
													<li>Enter Shoptins as Merchant</li>
													<li>Enter amount to pay</li>
													<li>Enter <b><?php echo e(session()->get('order_id')); ?></b> as
														reference
													</li>
													<li>Enter your pin</li>
												</ol>
											</div>
											<div class="card-footer">
												<label class="switch">
													<input type="checkbox" name="payment_type" value="momo">
													<span class="slider round"></span>
												</label>
											</div>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="card">
											<div class="card-header">
												<h4 class="card-title">Cash On Delivery</h4>
											</div>
											<div class="card-body">
												<ol>
													<li>An agent will contact you for confirmation.</li>
													<li>Please be sure to stay reachable.</li>
													<li>You need to ensure you have change or exact amount</li>
													<li>Call our support line if there is an emergency</li>
													<li>Arrangement will be made with you on how to receive package</li>
												</ol>
											</div>
											<div class="card-footer">
												<label class="switch">
													<input type="checkbox" name="payment_type" value="cash">
													<span class="slider round"></span>
												</label>
											</div>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="card">
											<div class="card-header">
												<h4 class="card-title">Bank Payment</h4>
											</div>
											<div class="card-body">
												<dl class="param">
													<dt>BANK:</dt>
													<dd> GT BANK</dd>
												</dl>
												<dl class="param">
													<dt>Account number:</dt>
													<dd> 12345678912345</dd>
												</dl>
												<dl class="param">
													<dt>Account Name:</dt>
													<dd> Shoptins</dd>
												</dl>
												
											</div>
											<div class="card-footer">
												<label class="switch">
													<input type="checkbox" name="payment_type" value="bank">
													<span class="slider round"></span>
												</label>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div style="margin-bottom: 10%" class="mt-4">
					<button class="btn btn-primary btn-lg btn-block" type="submit" style="cursor: pointer">
						<i class="fa fa-hand-point-right"></i>
						Place Your Order
					</button>
				</div>
			</form>


		</div>
	</section>
	<!--================End Track Area =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>