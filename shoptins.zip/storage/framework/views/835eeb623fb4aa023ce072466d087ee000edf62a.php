<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION INTRO ========================= -->
    <section class="section-intro text-white text-center">
        <div class="container d-flex flex-column mt-5 mb-5">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <article class="card-body">
                            <h4 class="card-title mb-4 mt-1 black">Sign in</h4>
                            <p>
                                <a href="" class="btn btn-block btn-twitter"> <i class="fab fa-twitter"></i> &nbsp; Login via Twitter</a>
                                <a href="" class="btn btn-block btn-facebook"> <i class="fab fa-facebook-f"></i> &nbsp; Login via facebook</a>
                            </p>
                            <hr>
                            <form method="post" action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group input-icon">
                                    <i class="fa fa-user"></i>
                                    <input name="email" class="form-control" placeholder="Email or login email"
                                           type="email">
                                </div> <!-- form-group// -->
                                <div class="form-group input-icon">
                                    <i class="fa fa-lock"></i>
                                    <input class="form-control" placeholder="******" type="password" name="password">
                                </div> <!-- form-group// -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary btn-block"> Login </button>
                                        </div> <!-- form-group// -->
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <a class="small" href="#">Forgot password?</a>
                                    </div>
                                </div> <!-- .row// -->
                            </form>
                        </article>
                    </div> <!-- card.// -->
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <article class="card-body">
                            <h4 class="card-title mb-4 mt-1 black">Sign Up</h4>
                            <?php if($errors->all()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <form method="post" action="<?php echo e(route('register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-row">
                                    <div class="col form-group">
                                        <input type="text" class="form-control" placeholder="First Name"
                                        name="first_name">
                                    </div>
                                    <div class="col form-group">
                                        <input type="text" class="form-control" placeholder="Last Name"
                                        name="last_name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email Address"
                                    name="email">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" type="password" placeholder="Enter Password"
                                    name="password">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" placeholder="Confirm Password"
                                    name="password_confirmation">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block"> Register  </button>
                                </div> <!-- form-group// -->
                                <small class="text-muted">By clicking the 'Register' button,
                                    you confirm that you accept our <br> Terms of use and Privacy Policy.</small>
                            </form>
                        </article>
                    </div> <!-- card.// -->
                </div>
            </div>
        </div>
    </section>
    <!-- ========================= SECTION INTRO END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>