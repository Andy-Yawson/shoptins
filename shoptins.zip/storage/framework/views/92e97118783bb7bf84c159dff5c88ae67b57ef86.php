<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">All Administrators</h4>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th>Created On</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($admin->name); ?></td>
                                    <td><?php echo e($admin->email); ?></td>
                                    <td>
                                        <?php if($admin->level == 0): ?>
                                            <button class="btn btn-info">Super Admin</button>
                                        <?php elseif($admin->level == 1): ?>
                                            <button class="btn btn-success">Normal Admin</button>
                                        <?php else: ?>
                                            <button class="btn btn-primary">Shop Owner</button>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Carbon\Carbon::parse($admin->created_at)->format('F d, Y H:i')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.delete.admin',$admin->id)); ?>"><i class="fa fa-trash-o fa-2x"></i></a>
                                       </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>