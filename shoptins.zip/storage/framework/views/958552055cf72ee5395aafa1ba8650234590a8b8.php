<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION PAGETOP ========================= -->
    <section class="section-pagetop bg-secondary">
        <div class="container clearfix">
            <h2 class="title-page">My Account</h2>
        </div> <!-- container //  -->
    </section>
    <!-- ========================= SECTION INTRO END// ========================= -->

    <!--================login Area =================-->
    <section class="emty_cart_area p_100">
        <div class="container">
            <div class="row mt-3 mb-3">
                <div class="col-md-4">
                    <aside class="mb-2">
                        <div class="card">
                            <header class="card-header white category-header">
                                <i class="icon-menu"></i>
                                My Account
                            </header>
                            <ul class="menu-category">
                                <li><a href="<?php echo e(route('user.account.orders')); ?>">My Orders</a></li>
                                <li><a href="#">Change Password</a></li>
                                <li><a href="#">Check Current Order Status</a></li>
                            </ul>
                        </div> <!-- card.// -->
                    </aside>
                </div>
                <div class="col-md-8">
                    <div class="card">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/password.blade.php ENDPATH**/ ?>