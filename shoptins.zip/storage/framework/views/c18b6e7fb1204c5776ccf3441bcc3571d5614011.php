<?php $__env->startSection('content'); ?>

	<!-- ========================= SECTION PAGETOP ========================= -->
	<section class="section-pagetop bg-secondary">
		<div class="container clearfix">
			<h2 class="title-page">My Account</h2>
		</div> <!-- container //  -->
	</section>
	<!-- ========================= SECTION INTRO END// ========================= -->

	<!--================login Area =================-->
	<section class="emty_cart_area p_100">
		<div class="container">
			<div class="row mt-5 mb-5">
				<div class="col-md-3">
					<aside class="mb-2">
						<div class="card">
							<header class="card-header white category-header">
								<i class="icon-menu"></i>
								Shoptins Account
							</header>
							<?php echo $__env->make('user.account.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div> <!-- card.// -->
					</aside>
				</div>
				<div class="col-md-9">
					<?php if(session('status')): ?>
						<div class="alert alert-success" role="alert">
							<button type="button" class="close" data-dismiss="alert">x</button>
							<?php echo e(session('status')); ?>

						</div>
					<?php endif; ?>
					<?php if(session('success')): ?>
						<div class="alert alert-success" role="alert">
							<button type="button" class="close" data-dismiss="alert">x</button>
							<?php echo e(session('success')); ?>

						</div>
					<?php endif; ?>
					<?php if(session('error')): ?>
						<div class="alert alert-danger" role="alert">
							<button type="button" class="close" data-dismiss="alert">x</button>
							<?php echo e(session('error')); ?>

						</div>
					<?php endif; ?>
					<div class="card">
						<article class="card-body">
							<h4 class="card-title mb-4 mt-1 black">Update Address</h4>
							<form method="post" action="<?php echo e(route('user.post.address')); ?>">
								<?php echo e(csrf_field()); ?>

								<div class="form-group">
									<label for="phone">Full Name</label>
									<input type="text" class="form-control" id="phone" aria-describedby="phone" readonly
									       name="shipping_name" value="<?php if(auth()->check()): ?><?php echo e(auth()->user()->name); ?><?php endif; ?>">
								</div>

								<div class="form-group">
									<label for="address">Address <span>*</span></label>
									<input type="text" class="form-control" id="address" aria-describedby="address" required
									       name="shipping_address" value="<?php if(!empty($shipping)): ?><?php echo e($shipping->shipping_address); ?><?php endif; ?>">
								</div>

								<div class="form-group">
									<label for="ctown">City / Town <span>*</span></label>
									<input type="text" class="form-control" id="address" aria-describedby="Town/City" required
									       name="shipping_city" value="<?php if(!empty($shipping)): ?><?php echo e($shipping->shipping_city); ?><?php endif; ?>">
								</div>

								<div class="form-group">
									<label for="email">Email <span>*</span></label>
									<input type="email" class="form-control" id="email" aria-describedby="email"
									       value="<?php if(auth()->check()): ?><?php echo e(auth()->user()->email); ?><?php endif; ?>"
									       name="shipping_email" readonly>
								</div>

								<div class="form-group">
									<label for="phone">Phone <span>*</span></label>
									<input type="text" class="form-control" id="phone" aria-describedby="phone" required
									       name="shipping_phone" value="<?php if(!empty($shipping)): ?><?php echo e($shipping->shipping_phone); ?><?php endif; ?>">
								</div>

								<div class="form-group">
									<label for="order">Order Notes</label>
									<textarea class="form-control" id="order" rows="3"
									          name="shipping_notes"><?php if(!empty($shipping)): ?><?php echo e($shipping->shipping_notes); ?><?php endif; ?></textarea>
								</div>

								<div class="form-group">
									<button type="submit" class="btn btn-info">
										<i class="fa fa-hand-point-right"></i>
										Update Address
									</button>
								</div>
							</form>
						</article>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/user/account/address.blade.php ENDPATH**/ ?>