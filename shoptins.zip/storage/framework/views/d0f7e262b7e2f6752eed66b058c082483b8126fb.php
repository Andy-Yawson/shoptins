<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">All International Orders</h4>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Order Code</th>
                                <th>Customer Name</th>
                                <th>Customer Email</th>
                                <th>Order Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Order Code</th>
                                <th>Customer Name</th>
                                <th>Customer Email</th>
                                <th>Order Status</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->order_code); ?></td>
                                    <td><?php echo e($order->name); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td>
                                        <?php if($order->status == 0): ?>
                                            <p class="text-info">Pending</p>
                                        <?php elseif($order->status == 1): ?>
                                            <p class="text-success">Confirmed</p>
                                        <?php elseif($order->status == 2): ?>
                                            <p class="text-danger">Declined</p>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.view.order.detail.int',$order->order_code)); ?>">
                                            <button class="btn btn-success">
                                                <i class="fa fa-bookmark"></i>
                                                Manage Order
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>