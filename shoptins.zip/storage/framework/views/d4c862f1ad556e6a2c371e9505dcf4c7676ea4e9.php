<?php $__env->startSection('content'); ?>



    <!--================login Area =================-->
    <section class="emty_cart_area p_100">
        <div class="container">
            <div class="empty-cart-div" align="center">
                <img src="<?php echo e(asset('images/empty-cart.svg')); ?>" width="200px" height="200px">
                <h3 class="mt-4 mb-4">Your Cart is Empty</h3>
                <h4>back to <a href="<?php echo e(route('user.shop')); ?>">shopping</a></h4>
            </div>
        </div>
    </section>
    <!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>