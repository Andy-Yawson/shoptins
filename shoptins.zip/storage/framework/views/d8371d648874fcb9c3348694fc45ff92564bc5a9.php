

<?php $__env->startSection('content'); ?>
    <div id="mainContent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h4 class="c-grey-900 mB-20">All Logged Products Activities</h4>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert">x</button>
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>Log ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Action Taken</th>
                                <th>Done by</th>
                                <th>Worked On</th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>Log ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Action Taken</th>
                                <th>Done by</th>
                                <th>Worked On</th>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $productLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->log_id); ?></td>
                                    <td><?php echo e($log->product_name); ?></td>
                                    <td><?php echo e($log->product_price); ?></td>
                                    <td>
                                        <?php if($log->product_status == 1): ?>
                                            <button class="btn btn-danger">Activated Product</button>
                                        <?php elseif($log->product_status == 2): ?>
                                                <button class="btn btn-danger">Unactivated Product</button>
                                        <?php elseif($log->product_status == 3): ?>
                                                <button class="btn btn-danger">Deleted Product</button>
                                        <?php elseif($log->product_status == 4): ?>
                                                <button class="btn btn-danger">Activated Stock</button>
                                        <?php elseif($log->product_status == 5): ?>
                                                <button class="btn btn-danger">Unactivated Stock</button>
                                        <?php elseif($log->product_status == 6): ?>
                                                <button class="btn btn-danger">Updated Product</button>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($log->name); ?></td>
                                    <td>
                                        <?php echo e(Carbon\Carbon::parse($log->created_at)->format('F d, Y H:i')); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>