<?php $__env->startSection('content'); ?>

    <!-- ========================= SECTION INTRO ========================= -->
    <section class="section-intro text-white text-center">
        <div class="container d-flex flex-column mt-5 mb-5">
            <?php if($errors->all()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <article class="card-body">
                            <h4 class="card-title mb-4 mt-1 black">Sign in</h4>
                            
                            <form method="post" action="<?php echo e(route('user.int.login.post')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> input-icon">
                                    <i class="fa fa-user"></i>
                                    <input name="email" class="form-control" placeholder="Email or login email"
                                           type="email" value="<?php echo e(old('email')); ?>">
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div> <!-- form-group// -->
                                <div class="form-group input-icon">
                                    <i class="fa fa-lock"></i>
                                    <input class="form-control" placeholder="******" type="password" name="password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div> <!-- form-group// -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary btn-block"> Login </button>
                                        </div> <!-- form-group// -->
                                    </div>
                                    
                                </div> <!-- .row// -->
                            </form>
                        </article>
                    </div> <!-- card.// -->
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <article class="card-body">
                            <h4 class="card-title mb-4 mt-1 black">Sign Up</h4>
                            <form method="post" action="<?php echo e(route('user.int.register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-row">
                                    <div class="col form-group">
                                        <input type="text" class="form-control" placeholder="First Name"
                                        name="first_name" required value="<?php echo e(old('first_name')); ?>">
                                    </div>
                                    <div class="col form-group">
                                        <input type="text" class="form-control" placeholder="Last Name"
                                        name="last_name" required value="<?php echo e(old('last_name')); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email Address"
                                    name="email" required value="<?php echo e(old('email')); ?>">
                                </div>

                                <div class="form-group">
                                    <input type="number" class="form-control" placeholder="Phone Number"
                                    name="phone" min="1" required value="<?php echo e(old('phone')); ?>">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" type="password" placeholder="Enter Password"
                                    name="password" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" placeholder="Confirm Password"
                                    name="password_confirmation" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block"> Register  </button>
                                </div> <!-- form-group// -->
                                <small class="text-muted">By clicking the 'Register' button,
                                    you confirm that you accept our <br> <a href="<?php echo e(route('user.terms')); ?>">Terms of use and Privacy Policy</a> .</small>
                            </form>
                        </article>
                    </div> <!-- card.// -->
                </div>
            </div>
        </div>
    </section>
    <!-- ========================= SECTION INTRO END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterint', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/auth/int-login.blade.php ENDPATH**/ ?>