<?php $__env->startSection('content'); ?>

	<!-- ========================= SECTION PAGETOP ========================= -->
	<section class="section-pagetop bg-secondary">
		<div class="container clearfix">
			<h2 class="title-page">My Account</h2>
		</div> <!-- container //  -->
	</section>
	<!-- ========================= SECTION INTRO END// ========================= -->

	<!--================login Area =================-->
	<section class="emty_cart_area p_100">
		<div class="container">
			<div class="row mt-5 mb-5">
				<div class="col-md-3">
					<aside class="mb-2">
						<div class="card">
							<header class="card-header white category-header">
								<i class="icon-menu"></i>
								Shoptins Account
							</header>
							<?php echo $__env->make('user.account.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div> <!-- card.// -->
					</aside>
				</div>
				<div class="col-md-9">
						<?php if(count($orders) > 0): ?>
							<?php if(session('status')): ?>
								<div class="alert alert-success" role="alert">
									<button type="button" class="close" data-dismiss="alert">x</button>
									<?php echo e(session('status')); ?>

								</div>
							<?php endif; ?>
							<div>
								<h3 class="title">All Available Orders</h3>
							</div>
							<table id="dataTable" class="table table-striped" cellspacing="0"
							       width="100%">
								<thead>
								<tr>
									<th>Order Code</th>
									<th>Payment Type</th>
									<th>Payment</th>
									<th>Order Total</th>
									<th>Delivery Status</th>
									<th>Action</th>
								</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($order->order_code); ?></td>
										<td><?php echo e($order->payment_method); ?></td>
										<td>
											<?php if($order->payment_status == 0): ?>
												<button class="btn btn-info">unpaid</button>
											<?php else: ?>
												<button class="btn btn-success">Paid</button>
											<?php endif; ?>
										</td>
										<td>&#8373;<?php echo e($order->order_total); ?></td>
										<td>
											<?php if($order->order_status == 0): ?>
												<button class="btn btn-info">Pending</button>
											<?php elseif($order->order_status == 1): ?>
												<button class="btn btn-primary">Confirmed</button>
											<?php elseif($order->order_status == 2): ?>
												<button class="btn btn-primary">Delivered</button>
											<?php elseif($order->order_status == 3): ?>
												<button class="btn btn-danger">Declined</button>
											<?php endif; ?>
										</td>
										<td align="center">
											<a href="<?php echo e(route('user.account.detail',$order->order_id)); ?>" class="btn btn-primary" title="View Order Detail">
												View Detail
											</a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						<?php else: ?>
							<h3>You have not made any local orders yet</h3>
						<?php endif; ?>
						<?php if(count($int_orders)): ?>
							<hr>
							<h3>Your International Orders</h3>
								<table id="dataTable" class="table table-striped" cellspacing="0"
								       width="100%">
									<thead>
									<tr>
										<th>Order Code</th>
										<th>Payment</th>
										<th>Order Total</th>
										<th>Action</th>
									</tr>
									</thead>
									<tbody>
									<?php $__currentLoopData = $int_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($order->order_code); ?></td>
											<td>
												<?php if($order->payment == 0): ?>
													<button class="btn btn-warning">Not Paid</button>
												<?php elseif($order->payment == 1): ?>
													<button class="btn btn-success">Paid</button>
												<?php endif; ?>
											</td>
											<td>
												<?php
												$checks = \Illuminate\Support\Facades\DB::table('international')
													->where('code',$order->order_code)
													->sum('price');

												echo $checks;
												?>
											</td>
											<td>
												<?php if($order->status == 1): ?>
													<button class="btn btn-success">Approved</button>
												<?php elseif($order->status == 0): ?>
													<button class="btn btn-info">Pending</button>
												<?php elseif($order->status == 2): ?>
													<button class="btn btn-danger">Declined</button>
												<?php endif; ?>
												<a href="<?php echo e(route('user.account.detail.int',$order->order_code)); ?>"
												   class="btn btn-info" title="View Detail">
													View Detail
												</a>
											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
						<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
	<!--================End login Area =================-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoptins\resources\views/user/account/orders.blade.php ENDPATH**/ ?>